# Hide CIRCUITPY, keep HID active, with a maintenance override on boot.

import time
import board
import digitalio
import storage
import usb_cdc
import usb_midi
import usb_hid

# -------- Maintenance override: hold both inputs at boot --------
# Pull-ups: pressed = False when tied to ground
tip = digitalio.DigitalInOut(board.TIP)
tip.switch_to_input(pull=digitalio.Pull.UP)

try:
    ring1_pin = board.RING_1
except AttributeError:
    ring1_pin = board.RING1
ring1 = digitalio.DigitalInOut(ring1_pin)
ring1.switch_to_input(pull=digitalio.Pull.UP)

override = False
start = time.monotonic()
while time.monotonic() - start < 2.0:
    if (tip.value is False) and (ring1.value is False):
        override = True
        break
    time.sleep(0.01)

# -------- USB config --------
# Keep HID keyboard enabled
usb_hid.enable( (usb_hid.Device.KEYBOARD,) )

if override:
    # Maintenance: leave everything visible so you can edit files
    usb_cdc.enable(console=True, data=True)
    # MIDI optional
    usb_midi.enable()
    # Make sure drive is visible
    # (do NOT call storage.disable_usb_drive())
else:
    # Production: hide drive and serial
    usb_cdc.enable(console=False, data=False)
    usb_midi.disable()
    storage.disable_usb_drive()

# Ensure internal FS stays writable to your code even if drive is hidden
try:
    storage.remount("/", readonly=False)
except Exception:
    pass
