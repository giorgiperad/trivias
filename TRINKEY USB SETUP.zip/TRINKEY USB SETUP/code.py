import time, board, digitalio, usb_hid
from adafruit_hid.keyboard import Keyboard
from adafruit_hid.keycode import Keycode

# Optional RGB LED
try:
    import neopixel
    pixel = neopixel.NeoPixel(board.NEOPIXEL, 1, brightness=0.25, auto_write=True)
    def led(c): pixel[0] = c
except Exception:
    def led(_): pass

# Colors
IDLE  = (0, 255, 0)
SPACE = (0, 0, 255)
ENTER = (255, 255, 0)
BOTH  = (255, 0, 0)
CALIB = (128, 0, 128)

kbd = Keyboard(usb_hid.devices)

# Ground rail on RING_2 (CTIA)
gnd = digitalio.DigitalInOut(board.RING_2)
gnd.direction = digitalio.Direction.OUTPUT
gnd.value = False

# Inputs (active-low)
tip = digitalio.DigitalInOut(board.TIP)
tip.switch_to_input(pull=digitalio.Pull.UP)

sleeve = digitalio.DigitalInOut(board.SLEEVE)
sleeve.switch_to_input(pull=digitalio.Pull.UP)

try:
    ring1_pin = board.RING_1
except AttributeError:
    ring1_pin = board.RING1
ring1 = digitalio.DigitalInOut(ring1_pin)
ring1.switch_to_input(pull=digitalio.Pull.UP)

# Choose which Enter key your app wants
ENTER_CODE = Keycode.ENTER  # change to Keycode.ENTER if needed

# --- Auto-detect which contact is Enter (sleeve vs ring1) ---
led(CALIB)
start = time.monotonic()
sleeve_initial = sleeve.value
ring1_initial  = ring1.value
sleeve_moved = False
ring1_moved  = False

# watch ~1.0 s for any change (have Ben tap Enter a couple times if handy)
while time.monotonic() - start < 1.0:
    if sleeve.value != sleeve_initial:
        sleeve_moved = True
    if ring1.value != ring1_initial:
        ring1_moved = True
    time.sleep(0.005)

# Decide which input to use for Enter
use_sleeve_for_enter = False
if sleeve_moved and not ring1_moved:
    use_sleeve_for_enter = True
elif ring1_moved and not sleeve_moved:
    use_sleeve_for_enter = False
else:
    # tie or no movement: choose the one that is HIGH (released) at idle
    # prefer a line that isn't stuck low
    if sleeve.value and not ring1.value:
        use_sleeve_for_enter = True
    elif ring1.value and not sleeve.value:
        use_sleeve_for_enter = False
    else:
        # last resort default to ring1 (common)
        use_sleeve_for_enter = False

# Helpers to read chosen Enter line and name it
def enter_raw():
    return sleeve.value if use_sleeve_for_enter else ring1.value  # True = released, False = pressed

led(IDLE)
kbd.release_all()

# State and debounce
DEBOUNCE_MS = 20
def now_ms(): return int(time.monotonic() * 1000)

space_down = False
enter_down = False

space_last_state = tip.value       # True = released
enter_last_state = enter_raw()     # True = released

space_last_change = 0
enter_last_change = 0

while True:
    tms = now_ms()

    # Read active-low states
    tip_active   = (tip.value is False)
    Enter_active = (enter_raw() is False)

    # Debounce SPACE
    if (tip_active != (space_last_state is False)) and (tms - space_last_change >= DEBOUNCE_MS):
        space_last_state = not tip_active
        space_last_change = tms
        if tip_active and not space_down:
            kbd.press(Keycode.SPACE)
            space_down = True
        elif not tip_active and space_down:
            kbd.release(Keycode.SPACE)
            space_down = False

    # Debounce ENTER
    if (Enter_active != (enter_last_state is False)) and (tms - enter_last_change >= DEBOUNCE_MS):
        enter_last_state = not Enter_active
        enter_last_change = tms
        if Enter_active and not enter_down:
            kbd.press(ENTER_CODE)
            enter_down = True
        elif not Enter_active and enter_down:
            kbd.release(ENTER_CODE)
            enter_down = False

    # LED
    if space_down and enter_down:
        led(BOTH)
    elif space_down:
        led(SPACE)
    elif enter_down:
        led(ENTER)
    else:
        led(IDLE)

    time.sleep(0.005)
